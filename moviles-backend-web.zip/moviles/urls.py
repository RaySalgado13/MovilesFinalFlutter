from rest_framework import routers

from .views import CategoryViewSet, ServiceViewSet, EmployeeViewSet, AgendaViewSet, PromotionViewSet

router = routers.SimpleRouter()
router.register("categories", CategoryViewSet, basename="categories")
router.register("services", ServiceViewSet, basename="services")
router.register("employees", EmployeeViewSet, basename="employees")
router.register("agenda", AgendaViewSet, basename="agenda")
router.register("promotions", PromotionViewSet, basename="promotions")

urlpatterns = router.urls 
