from rest_framework import viewsets, mixins
from django.contrib.auth.models import User

from rest_framework.response import Response
from rest_framework import serializers

import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
from firebase_admin import auth

cred = credentials.Certificate('secret.json')
firebase_admin.initialize_app(cred)
firestore_client = firestore.client()


def get_user(request):
    token = request.COOKIES.get('token')
    decoded_token = auth.verify_id_token(token)
    uid = decoded_token['uid']
    return uid


def entity_wrapper(entity):
    data = entity.to_dict()
    print(data)
    data["id"] = entity.id
    return data


class CategorySerializer(serializers.Serializer):
    uid = serializers.CharField()
    name = serializers.CharField()


class ServiceSerializer(serializers.Serializer):
    uid = serializers.CharField()
    name = serializers.CharField()
    category = serializers.CharField()
    cost = serializers.FloatField()


class EmpleadoSerializer(serializers.Serializer):
    name = serializers.CharField()
    email = serializers.CharField()
    rfc = serializers.CharField()
    curp = serializers.CharField()


class AgendaSerializer(serializers.Serializer):
    servicio = serializers.CharField()
    empleado = serializers.CharField()
    horario = serializers.CharField()


class BaseViewSet(mixins.CreateModelMixin,
                  mixins.RetrieveModelMixin,
                  mixins.UpdateModelMixin,
                  mixins.DestroyModelMixin,
                  mixins.ListModelMixin,
                  viewsets.GenericViewSet):
    collection = ""

    def list(self, request, *args, **kwargs):
        ref = firestore_client.collection(self.collection)
        items = ref.get()
        return Response(status=200, data=[entity_wrapper(i) for i in items])

    def retrieve(self, request, *args, **kwargs):
        ref = firestore_client.collection(self.collection)
        item = ref.document(kwargs["pk"]).get()
        return Response(status=200, data=entity_wrapper(item))

    def create(self, request, *args, **kwargs):
        ref = firestore_client.collection(self.collection)
        data = {k: v for k, v in request.data.items() if v is not None}
        del data["token"]
        ref.add(data)
        return Response(status=201)

    def update(self, request, *args, **kwargs):
        ref = firestore_client.collection(self.collection)
        data = {**request.data}
        del data["token"]
        ref.document(kwargs["pk"]).update(data)
        return Response(status=200)

    def destroy(self, request, *args, **kwargs):
        ref = firestore_client.collection(self.collection)
        ref.document(kwargs["pk"]).delete()
        return Response(status=200)


class CategoryViewSet(BaseViewSet):
    serializer_class = CategorySerializer
    queryset = User.objects.all()
    collection = "categories"


class ServiceViewSet(BaseViewSet):
    serializer_class = ServiceSerializer
    queryset = User.objects.all()
    collection = "services"


class EmployeeViewSet(BaseViewSet):
    serializer_class = EmpleadoSerializer
    queryset = User.objects.all()
    collection = "employees"


class AgendaViewSet(BaseViewSet):
    serializer_class = AgendaSerializer
    queryset = User.objects.all()
    collection = "agenda"
