import React, { useState } from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import { Alert, Spinner } from "react-bootstrap";

export { RegistrarPromocion };

function RegistrarPromocion(): React.ReactElement {
  const [loading, setLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);

  async function handleRegisterPromotion() {
    const form = document.getElementById(
      "formRegisterPromotion"
    ) as HTMLFormElement;
    const name = form.elements.namedItem("name").value;
    const description = form.description.value;
    const data = {
      name,
      description,
    };
    setLoading(true);
    try {
      const response = await fetch("http://localhost:8000/api/promotions/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      if (response.status === 201) {
        setShowAlert(true);
      }
    } catch {
      /* empty */
    } finally {
      setLoading(false);
    }
  }

  return (
    <BaseContainer>
      <h1
        css={{
          alignSelf: "center",
          marginTop: "2rem",
        }}
      >
        Registrar Promoción
      </h1>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        {loading && (
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        )}
        <Form id={"formRegisterPromotion"}>
          <Form.Group className="mb-3" controlId="name">
            <Form.Label>Nombre</Form.Label>
            <Form.Control placeholder="Nombre" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="description">
            <Form.Label>Descripción</Form.Label>
            <Form.Control placeholder="Descripción" />
          </Form.Group>
          <Button
            variant="primary"
            type="button"
            onClick={handleRegisterPromotion}
          >
            Guardar
          </Button>
        </Form>
        {showAlert && (
          <Alert
            variant={"success"}
            css={{ marginTop: "2rem" }}
            dismissible
            onClose={() => setShowAlert(false)}
          >
            Promoción creada exitosamente
          </Alert>
        )}
      </Container>
    </BaseContainer>
  );
}
