import React, { useState } from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Container from "react-bootstrap/Container";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Button from "react-bootstrap/Button";
import { Alert } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

export { Empleados };

function Empleados(): React.ReactElement {
  const [alertVariant, setAlertVariant] = useState("");
  const [alertText, setAlertText] = useState("");
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const employeesQuery = useQuery({
    queryKey: ["employees"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/employees/");
      return await response.json();
    },
  });

  const employees = employeesQuery.data ?? [];

  const employeeDeleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const url = `http://localhost:8000/api/employees/${id}/`;
      const response = await fetch(url, {
        method: "DELETE",
      });
    },
    onSuccess: async () => {
      setAlertVariant("success");
      setAlertText("Empleado eliminado correctamente");
      await queryClient.invalidateQueries({ queryKey: ["employees"] });
    },
    onError: () => {
      setAlertVariant("danger");
      setAlertText("Error al eliminar el empleado");
    },
  });

  return (
    <BaseContainer>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        <h1
          css={{
            alignSelf: "center",
            marginTop: "2rem",
            textAlign: "center",
          }}
        >
          Empleados
        </h1>
        <Button
          onClick={() => navigate("/registrar-empleado")}
          css={{ marginTop: "2rem" }}
        >
          Crear Empleado
        </Button>
        <div
          css={{
            display: "flex",
            marginTop: "2rem",
            flexDirection: "column",
            alignItems: "stretch",
            gap: "1rem",
          }}
        >
          {employees.map((employee) => (
            <div
              key={employee.id}
              css={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                padding: "1rem",
                border: "1px solid black",
                borderRadius: "1rem",
                backgroundColor: "rgb(245, 245, 245)",
              }}
            >
              <div>
                {employee.name} {employee.lastName}
              </div>
              <div>
                <Button css={{ marginRight: "1rem" }} variant={"primary"} onClick={() => navigate(
                  `/editar-empleado/${employee.id}`
                )}>
                  Editar
                </Button>
                <Button
                  variant={"danger"}
                  onClick={() => employeeDeleteMutation.mutate(employee.id)}
                >
                  Eliminar
                </Button>
              </div>
            </div>
          ))}
          <Alert variant={alertVariant} show={alertText !== ""}>
            {alertText}
          </Alert>
        </div>
      </Container>
    </BaseContainer>
  );
}
