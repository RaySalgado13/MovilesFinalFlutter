import React, { useEffect, useState } from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import { Alert, Spinner } from "react-bootstrap";
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";

export { EditarEmpleado };

function EditarEmpleado(): React.ReactElement {
  const [loading, setLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const { id } = useParams();

  const employeeQuery = useQuery({
    queryKey: ["employee", id],
    queryFn: async () => {
      const response = await fetch(`http://localhost:8000/api/employees/${id}`);
      return await response.json();
    },
  });

  const employee = employeeQuery.data;

  useEffect(() => {
    if (employee) {
      const form = document.getElementById(
        "formRegisterEmployee"
      ) as HTMLFormElement;
      form.elements.namedItem("name").value = employee.name;
      form.elements.namedItem("email").value = employee.email;
      form.elements.namedItem("lastName").value = employee.lastName;
      form.elements.namedItem("phone").value = employee.phone;
      form.elements.namedItem("curp").value = employee.curp;
    }
  }, [employee]);

  async function handleEditEmployee() {
    const form = document.getElementById(
      "formRegisterEmployee"
    ) as HTMLFormElement;
    const name = form.elements.namedItem("name").value;
    const lastName = form.lastName.value;
    const email = form.email.value;
    const phone = form.phone.value;
    const curp = form.curp.value;
    const data = {
      name,
      lastName,
      email,
      phone,
      curp,
    };
    setLoading(true);
    try {
      const response = await fetch(
        `http://localhost:8000/api/employees/${id}/`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }
      );
      if (response.status === 200) {
        setShowAlert(true);
      }
    } catch {
      /* empty */
    } finally {
      setLoading(false);
    }
  }

  return (
    <BaseContainer>
      <h1
        css={{
          alignSelf: "center",
          marginTop: "2rem",
        }}
      >
        Editar Empleado
      </h1>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        {loading && (
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        )}
        <Form id={"formRegisterEmployee"}>
          <Form.Group className="mb-3" controlId="name">
            <Form.Label>Nombre</Form.Label>
            <Form.Control placeholder="Nombre" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="lastName">
            <Form.Label>Apellido</Form.Label>
            <Form.Control placeholder="Apellido" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="email">
            <Form.Label>Email</Form.Label>
            <Form.Control placeholder="Email" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="phone">
            <Form.Label>Telefono</Form.Label>
            <Form.Control placeholder="Telefono" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="curp">
            <Form.Label>CURP</Form.Label>
            <Form.Control placeholder="CURP" />
          </Form.Group>

          <Button variant="primary" type="button" onClick={handleEditEmployee}>
            Guardar
          </Button>
        </Form>
        {showAlert && (
          <Alert
            variant={"success"}
            css={{ marginTop: "2rem" }}
            dismissible
            onClose={() => setShowAlert(false)}
          >
            Empleado actualizado exitosamente
          </Alert>
        )}
      </Container>
    </BaseContainer>
  );
}
