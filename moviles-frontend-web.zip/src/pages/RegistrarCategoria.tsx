import React, { useState } from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import { Alert, Spinner } from "react-bootstrap";

export { RegistrarCategoria };

function RegistrarCategoria(): React.ReactElement {
  const [loading, setLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);

  async function handleRegisterCategory() {
    const form = document.getElementById(
      "formRegisterCategory"
    ) as HTMLFormElement;
    const name = form.elements.namedItem("name").value;
    const data = {
      name,
    };
    setLoading(true);
    try {
      const response = await fetch("http://localhost:8000/api/categories/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      if (response.status === 201) {
        setShowAlert(true);
      }
    } catch {
      /* empty */
    } finally {
      setLoading(false);
    }
  }

  return (
    <BaseContainer>
      <h1
        css={{
          alignSelf: "center",
          marginTop: "2rem",
        }}
      >
        Registrar Categoría
      </h1>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        {loading && (
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        )}
        <Form id={"formRegisterCategory"}>
          <Form.Group className="mb-3" controlId="name">
            <Form.Label>Nombre</Form.Label>
            <Form.Control placeholder="Nombre" />
          </Form.Group>

          <Button
            variant="primary"
            type="button"
            onClick={handleRegisterCategory}
          >
            Guardar
          </Button>
        </Form>
        {showAlert && (
          <Alert
            variant={"success"}
            css={{ marginTop: "2rem" }}
            dismissible
            onClose={() => setShowAlert(false)}
          >
            Categoría creada exitosamente
          </Alert>
        )}
      </Container>
    </BaseContainer>
  );
}
