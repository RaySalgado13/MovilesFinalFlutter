import React, { useState } from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import { Alert, Spinner } from "react-bootstrap";
import { useQuery } from "@tanstack/react-query";

export { RegistrarServicio };

function RegistrarServicio(): React.ReactElement {
  const [loading, setLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const categoriesQuery = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/categories/");
      return await response.json();
    },
  });

  const categories = categoriesQuery?.data ?? [];

  const employeesQuery = useQuery({
    queryKey: ["employees"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/employees/");
      return await response.json();
    },
  });

  const employees = employeesQuery.data ?? [];

  async function handleRegisterService() {
    const form = document.getElementById(
      "formRegisterService"
    ) as HTMLFormElement;
    const name = form.elements.namedItem("name").value;
    const description = form.elements.namedItem("description").value;
    const price = form.price.value;
    const category = form.category.value;
    const duration = form.duration.value;
    const selectedStaff = document.querySelectorAll(
      "#select-staff option:checked"
    );
    const staff = Array.from(selectedStaff).map((el) => el.value);
    const data = {
      name,
      description,
      price,
      category,
      duration,
      staff,
    };
    setLoading(true);
    try {
      const response = await fetch("http://localhost:8000/api/services/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      if (response.status === 201) {
        setShowAlert(true);
      }
    } catch {
      /* empty */
    } finally {
      setLoading(false);
    }
  }

  return (
    <BaseContainer>
      <h1
        css={{
          alignSelf: "center",
          marginTop: "2rem",
        }}
      >
        Registrar Servicio
      </h1>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        {loading && (
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        )}
        <Form id={"formRegisterService"}>
          <Form.Group className="mb-3" controlId="name">
            <Form.Label>Nombre</Form.Label>
            <Form.Control placeholder="Nombre" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="description">
            <Form.Label>Descripción</Form.Label>
            <Form.Control placeholder="Descripción" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="price">
            <Form.Label>Precio</Form.Label>
            <Form.Control placeholder="Precio" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="category">
            <Form.Label>Categoría</Form.Label>
            <Form.Select>
              {categories.map((category) => (
                <option value={category.id}>{category.name}</option>
              ))}
            </Form.Select>
          </Form.Group>
          <Form.Group className="mb-3" controlId="staff">
            <Form.Label>Empleados</Form.Label>
            <Form.Select multiple id={"select-staff"}>
              {employees.map((employee) => (
                <option value={employee.id}>
                  {employee.name} {employee.lastName}
                </option>
              ))}
            </Form.Select>
          </Form.Group>
          <Form.Group className="mb-3" controlId="duration">
            <Form.Label>Duración</Form.Label>
            <Form.Control placeholder="Duración" />
          </Form.Group>

          <Button
            variant="primary"
            type="button"
            onClick={handleRegisterService}
          >
            Guardar
          </Button>
        </Form>
        {showAlert && (
          <Alert
            variant={"success"}
            css={{ marginTop: "2rem" }}
            dismissible
            onClose={() => setShowAlert(false)}
          >
            Servicio creado exitosamente
          </Alert>
        )}
      </Container>
    </BaseContainer>
  );
}
