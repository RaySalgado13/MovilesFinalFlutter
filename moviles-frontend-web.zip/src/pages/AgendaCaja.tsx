import React, { useState } from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Container from "react-bootstrap/Container";
import { Alert, Spinner } from "react-bootstrap";
import { useQuery } from "@tanstack/react-query";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";

export { AgendaCaja };

function AgendaCaja(): React.ReactElement {
  const [loading, setLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);

  const employeesQuery = useQuery({
    queryKey: ["employees"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/employees/");
      return await response.json();
    },
  });

  const servicesQuery = useQuery({
    queryKey: ["services"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/services/");
      return await response.json();
    },
  });

  const employees = employeesQuery.data ?? [];
  const services = servicesQuery.data ?? [];

  async function handleRegisterAgenda() {
    const form = document.getElementById(
      "formRegisterAgenda"
    ) as HTMLFormElement;
    const name = form.elements.namedItem("name").value;
    const service = form.service.value;
    const employee = form.employee.value;
    const datetime = form.datetime.value;
    const date = datetime.split("T")[0];
    const time = datetime.split("T")[1];
    const data = {
      service,
      employee,
      date,
      time,
      name,
    };
    setLoading(true);
    try {
      const response = await fetch("http://localhost:8000/api/agenda/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      if (response.status === 201) {
        setShowAlert(true);
      }
    } catch {
      /* empty */
    } finally {
      setLoading(false);
    }
  }

  return (
    <BaseContainer>
      <h1
        css={{
          alignSelf: "center",
          marginTop: "2rem",
        }}
      >
        Agendar una cita
      </h1>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        {loading && (
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        )}
        <Form id={"formRegisterAgenda"}>
          <Form.Group className="mb-3" controlId="service">
            <Form.Label>Servicio</Form.Label>
            <Form.Select>
              {services.map((service) => (
                <option key={service.id} value={service.id}>
                  {service.name} - ${service.price}
                </option>
              ))}
            </Form.Select>
          </Form.Group>
          <Form.Group className="mb-3" controlId="employee">
            <Form.Label>Empleado</Form.Label>
            <Form.Select>
              {employees.map((employee) => (
                <option key={employee.id} value={employee.id}>
                  {employee.name} {employee.lastName}
                </option>
              ))}
            </Form.Select>
          </Form.Group>
          <Form.Group className="mb-3" controlId="userEmail">
            <Form.Label>Email del Cliente</Form.Label>
            <Form.Control placeholder="Email del Cliente" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="datetime">
            <Form.Label>Fecha y Hora</Form.Label>
            <Form.Control type={"datetime-local"} />
          </Form.Group>

          <Button
            variant="primary"
            type="button"
            onClick={handleRegisterAgenda}
          >
            Guardar
          </Button>
        </Form>
        {showAlert && (
          <Alert
            variant={"success"}
            css={{ marginTop: "2rem" }}
            dismissible
            onClose={() => setShowAlert(false)}
          >
            Servicio creado exitosamente
          </Alert>
        )}
      </Container>
      <h1
        css={{
          alignSelf: "center",
          marginTop: "2rem",
        }}
      >
        Agendas
      </h1>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        {employees.map((employee) => {
          return (
            <>
              <div
                key={employee.id}
                css={{
                  display: "flex",
                  marginBottom: "1rem",
                  justifyContent: "space-between",
                  alignItems: "center",
                  padding: "1rem",
                  border: "1px solid black",
                  borderRadius: "1rem",
                  backgroundColor: "rgb(245, 245, 245)",
                }}
              >
                <Link to={`/agenda/${employee.id}`}>
                  {employee.name} {employee.lastName}
                </Link>
              </div>
            </>
          );
        })}
      </Container>
    </BaseContainer>
  );
}
