import React, { useEffect, useState } from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Container from "react-bootstrap/Container";
import { Alert } from "react-bootstrap";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Button from "react-bootstrap/Button";
import { useNavigate, useParams } from "react-router-dom";
import Form from "react-bootstrap/Form";

export { AgendaIndividual };

function getWeekNumber(d) {
  // Copy date so don't modify original
  d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  // Set to nearest Thursday: current date + 4 - current day number
  // Make Sunday's day number 7
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  // Get first day of year
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  // Calculate full weeks to nearest Thursday
  const weekNo = Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
  // Return array of year and week number
  return [d.getUTCFullYear(), weekNo];
}

function AgendaIndividual(): React.ReactElement {
  const [alertVariant, setAlertVariant] = useState("");
  const [alertText, setAlertText] = useState("");
  const [filterValue, setFilterValue] = useState("ALL");
  const [employeeAgendas, setEmployeeAgendas] = useState([]);
  const { id } = useParams();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const employeesQuery = useQuery({
    queryKey: ["employees"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/employees/");
      return await response.json();
    },
  });

  const servicesQuery = useQuery({
    queryKey: ["services"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/services/");
      return await response.json();
    },
  });

  const agendaQuery = useQuery({
    queryKey: ["agenda"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/agenda/");
      return await response.json();
    },
  });

  const employees = employeesQuery.data ?? [];
  const services = servicesQuery.data ?? [];
  const agenda = agendaQuery.data ?? [];

  const employee = employees.find((employee) => employee.id === id);

  const agendaDeleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const url = `http://localhost:8000/api/agenda/${id}/`;
      const response = await fetch(url, {
        method: "DELETE",
      });
    },
    onSuccess: async () => {
      setAlertVariant("success");
      setAlertText("Entrada de agenda eliminada correctamente");
      await queryClient.invalidateQueries({ queryKey: ["agenda"] });
    },
    onError: () => {
      setAlertVariant("danger");
      setAlertText("Error al eliminar el servicio");
    },
  });

  useEffect(() => {
    const today = new Date().toISOString().slice(0, 10);
    const currentWeekNumber = getWeekNumber(new Date())[1];
    const monthNumber = new Date().getMonth() + 1;
    switch (filterValue) {
      case "DAY":
        setEmployeeAgendas(
          agenda.filter((a) => a.employee === id && a.date === today)
        );
        break;
      case "WEEK":
        setEmployeeAgendas(
          agenda.filter(
            (a) =>
              a.employee === id &&
              getWeekNumber(new Date(a.date))[1] === currentWeekNumber
          )
        );
        break;
      case "QUINCENA":
        setEmployeeAgendas(
          agenda.filter(
            (a) =>
              a.employee === id &&
              (getWeekNumber(new Date(a.date))[1] === currentWeekNumber ||
                getWeekNumber(new Date(a.date))[1] === currentWeekNumber - 1)
          )
        );
        break;
      case "MONTH":
        setEmployeeAgendas(
          agenda.filter(
            (a) =>
              a.employee === id &&
              new Date(a.date).getMonth() + 1 === monthNumber
          )
        );
        break;
      default:
        setEmployeeAgendas(agenda.filter((a) => a.employee === id));
        break;
    }
  }, [filterValue, agenda, employee]);

  return (
    <BaseContainer>
      <h1
        css={{
          alignSelf: "center",
          marginTop: "2rem",
        }}
      >
        Agenda de {employee?.name} {employee?.lastName}
      </h1>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        <div
          css={{
            display: "flex",
            marginTop: "2rem",
            flexDirection: "column",
            alignItems: "stretch",
            gap: "1rem",
          }}
        >
          <Form.Group className="mb-3" controlId="category">
            <Form.Label>Filtrar Por</Form.Label>
            <Form.Select
              onChange={(e) => {
                setFilterValue(e.target.value);
              }}
            >
              <option value={"All"}>Todos</option>
              <option value={"DAY"}>Día</option>
              <option value={"WEEK"}>Semana</option>
              <option value={"QUINCENA"}>Quincena</option>
              <option value={"MONTH"}>Mes</option>
            </Form.Select>
          </Form.Group>
          {employeeAgendas.map((agenda) => {
            const service = services.find(
              (service) => service.id === agenda.service
            );
            console.log(service);
            return (
              <div
                key={agenda.id}
                css={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  padding: "1rem",
                  border: "1px solid black",
                  borderRadius: "1rem",
                  backgroundColor: "rgb(245, 245, 245)",
                }}
              >
                <div>
                  <span>
                    <b>{service.name}</b>{" "}
                  </span>
                  <br />
                  <span>{agenda.userEmail} </span>
                  <br />
                  <span>{agenda.date} </span>
                  <span>{agenda.time} </span>
                </div>
                <div>
                  <Button
                    variant={"danger"}
                    onClick={() => agendaDeleteMutation.mutate(agenda.id)}
                  >
                    Cancelar
                  </Button>
                </div>
              </div>
            );
          })}
          <Alert variant={alertVariant} show={alertText !== ""}>
            {alertText}
          </Alert>
        </div>
      </Container>
    </BaseContainer>
  );
}
