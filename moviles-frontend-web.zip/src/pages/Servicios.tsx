import React, { useState } from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Container from "react-bootstrap/Container";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Button from "react-bootstrap/Button";
import { Alert } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

export { Servicios };

function Servicios(): React.ReactElement {
  const [alertVariant, setAlertVariant] = useState("");
  const [alertText, setAlertText] = useState("");
  const [alertVariant2, setAlertVariant2] = useState("");
  const [alertText2, setAlertText2] = useState("");
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const servicesQuery = useQuery({
    queryKey: ["services"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/services/");
      return await response.json();
    },
  });

  const categoriesQuery = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/categories/");
      return await response.json();
    },
  });

  const services = servicesQuery.data ?? [];
  const categories = categoriesQuery.data ?? [];

  const serviceDeleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const url = `http://localhost:8000/api/services/${id}/`;
      const response = await fetch(url, {
        method: "DELETE",
      });
    },
    onSuccess: async () => {
      setAlertVariant("success");
      setAlertText("Servicio eliminado correctamente");
      await queryClient.invalidateQueries({ queryKey: ["services"] });
    },
    onError: () => {
      setAlertVariant("danger");
      setAlertText("Error al eliminar el servicio");
    },
  });

  const categoryDeleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const url = `http://localhost:8000/api/categories/${id}/`;
      const response = await fetch(url, {
        method: "DELETE",
      });
    },
    onSuccess: async () => {
      setAlertVariant2("success");
      setAlertText2("Categoria eliminada correctamente");
      await queryClient.invalidateQueries({ queryKey: ["categories"] });
    },
    onError: () => {
      setAlertVariant2("danger");
      setAlertText2("Error al eliminar la categoria");
    },
  });

  return (
    <BaseContainer>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        <h1
          css={{
            alignSelf: "center",
            marginTop: "2rem",
            textAlign: "center",
          }}
        >
          Servicios
        </h1>
        <Button
          onClick={() => navigate("/registrar-servicio")}
          css={{ marginTop: "2rem" }}
        >
          Crear Servicio
        </Button>
        <div
          css={{
            display: "flex",
            marginTop: "2rem",
            flexDirection: "column",
            alignItems: "stretch",
            gap: "1rem",
          }}
        >
          {services.map((service) => (
            <div
              key={service.id}
              css={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                padding: "1rem",
                border: "1px solid black",
                borderRadius: "1rem",
                backgroundColor: "rgb(245, 245, 245)",
              }}
            >
              <div>{service.name}</div>
              <div>
                <Button
                  css={{ marginRight: "1rem" }}
                  variant={"primary"}
                  onClick={() => navigate(`/editar-servicio/${service.id}`)}
                >
                  Editar
                </Button>
                <Button
                  variant={"danger"}
                  onClick={() => serviceDeleteMutation.mutate(service.id)}
                >
                  Eliminar
                </Button>
              </div>
            </div>
          ))}
          <Alert variant={alertVariant} show={alertText !== ""}>
            {alertText}
          </Alert>
        </div>
        <h1
          css={{
            alignSelf: "center",
            marginTop: "2rem",
            textAlign: "center",
          }}
        >
          Categorias
        </h1>
        <Button
          onClick={() => navigate("/registrar-categoria")}
          css={{ marginTop: "2rem" }}
        >
          Crear Categoria
        </Button>
        <div
          css={{
            display: "flex",
            marginTop: "2rem",
            flexDirection: "column",
            alignItems: "stretch",
            gap: "1rem",
          }}
        >
          {categories.map((category) => (
            <div
              key={category.id}
              css={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                padding: "1rem",
                border: "1px solid black",
                borderRadius: "1rem",
                backgroundColor: "rgb(245, 245, 245)",
              }}
            >
              <div>{category.name}</div>
              <div>
                <Button
                  css={{ marginRight: "1rem" }}
                  variant={"primary"}
                  onClick={() => navigate(`/editar-categoria/${category.id}`)}
                >
                  Editar
                </Button>
                <Button
                  variant={"danger"}
                  onClick={() => categoryDeleteMutation.mutate(category.id)}
                >
                  Eliminar
                </Button>
              </div>
            </div>
          ))}
          <Alert variant={alertVariant2} show={alertText2 !== ""}>
            {alertText2}
          </Alert>
        </div>
      </Container>
    </BaseContainer>
  );
}
