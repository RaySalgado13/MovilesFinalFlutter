import React, {useEffect, useState} from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import { Alert, Spinner } from "react-bootstrap";
import { useParams } from "react-router-dom";
import {useQuery} from "@tanstack/react-query";

export { EditarCategoria };

function EditarCategoria(): React.ReactElement {
  const [loading, setLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const { id } = useParams();

  const categoryQuery = useQuery({
    queryKey: ["category", id],
    queryFn: async () => {
      const response = await fetch(`http://localhost:8000/api/categories/${id}/`);
      return response.json();
    }
  })

  const category = categoryQuery.data;

  useEffect(() => {
    if (category) {
      const form = document.getElementById("formEditCategory") as HTMLFormElement;
      form.elements.namedItem("name").value = category.name;
    }
  }, [category])

  async function handleEditCategory() {
    const form = document.getElementById("formEditCategory") as HTMLFormElement;
    const name = form.elements.namedItem("name").value;
    const data = {
      name,
    };
    setLoading(true);
    try {
      const response = await fetch(
        `http://localhost:8000/api/categories/${id}/`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }
      );
      if (response.status === 200) {
        setShowAlert(true);
      }
    } catch {
      /* empty */
    } finally {
      setLoading(false);
    }
  }

  return (
    <BaseContainer>
      <h1
        css={{
          alignSelf: "center",
          marginTop: "2rem",
        }}
      >
        Editar Categoría
      </h1>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        {loading && (
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        )}
        <Form id={"formEditCategory"}>
          <Form.Group className="mb-3" controlId="name">
            <Form.Label>Nombre</Form.Label>
            <Form.Control placeholder="Nombre" />
          </Form.Group>

          <Button variant="primary" type="button" onClick={handleEditCategory}>
            Guardar
          </Button>
        </Form>
        {showAlert && (
          <Alert
            variant={"success"}
            css={{ marginTop: "2rem" }}
            dismissible
            onClose={() => setShowAlert(false)}
          >
            Categoría actualizada exitosamente
          </Alert>
        )}
      </Container>
    </BaseContainer>
  );
}
