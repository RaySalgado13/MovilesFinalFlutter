import React from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Container from "react-bootstrap/Container";

export { Home };

function Home(): React.ReactElement {
  return (
    <BaseContainer>
      <Container>
        <h1
          css={{
              marginTop: "1rem",
            textAlign: "center",
          }}
        >
          Bienvenido
        </h1>
      </Container>
    </BaseContainer>
  );
}
