import React from "react";
import { signInWithEmailAndPassword } from "firebase/auth";
import Container from "react-bootstrap/Container";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { auth } from "src/firebase.ts";
import { useNavigate } from "react-router-dom";

export { Login };

function setCookie(name, value, days) {
  let expires = "";
  if (days) {
    const date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    expires = ";expires=" + date.toUTCString();
  }
  document.cookie = name + "=" + (value || "") + expires + ";path=/";
}

function Login(): React.ReactElement {
  const navigate = useNavigate();

  async function handleLogin() {
    const form = document.getElementById("formLogin") as HTMLFormElement;
    const username = form.username.value;
    const password = form.password.value;
    try {
      const credentials = await signInWithEmailAndPassword(
        auth,
        username,
        password
      );
      const token = credentials.user.accessToken;
      if (username === "caja@yopmail.com") {
        localStorage.setItem("userType", "Caja");
      } else if (username === "gerente@yopmail.com") {
        localStorage.setItem("userType", "Gerente");
      } else {
        localStorage.setItem("userType", "Empleado");
      }
      localStorage.setItem("userEmail", username);
      localStorage.setItem("token", token);
      setCookie("token", token, 10);
      navigate("/");
    } catch {
      alert("Error al iniciar sesion");
    }
  }

  return (
    <Container
      css={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        height: "100%",
        backgroundColor: "rgb(240, 240, 240)",
      }}
      fluid
    >
      <div
        css={{
          backgroundColor: "white",
          boxShadow: "0px 0px 10px 0px rgba(0,0,0,0.2)",
          padding: "3rem",
          borderRadius: "1rem",
          minWidth: "500px",
        }}
      >
        <Form id={"formLogin"}>
          <Form.Group className="mb-3" controlId="username">
            <Form.Label>Nombre de Usuario</Form.Label>
            <Form.Control placeholder="Nombre de Usuario" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="password">
            <Form.Label>Contraseña</Form.Label>
            <Form.Control type={"password"} placeholder="Contraseña" />
          </Form.Group>

          <Button variant="primary" type="button" onClick={handleLogin}>
            Guardar
          </Button>
        </Form>
      </div>
    </Container>
  );
}
