import React, { useState } from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Container from "react-bootstrap/Container";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Button from "react-bootstrap/Button";
import { Alert } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

export { Promociones };

function Promociones(): React.ReactElement {
  const [alertVariant, setAlertVariant] = useState("");
  const [alertText, setAlertText] = useState("");
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const promotionsQuery = useQuery({
    queryKey: ["promotions"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/promotions/");
      return await response.json();
    },
  });

  const promotions = promotionsQuery.data ?? [];

  const promotionsDeleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const url = `http://localhost:8000/api/promotions/${id}/`;
      const response = await fetch(url, {
        method: "DELETE",
      });
    },
    onSuccess: async () => {
      setAlertVariant("success");
      setAlertText("Promoción eliminada correctamente");
      await queryClient.invalidateQueries({ queryKey: ["promotions"] });
    },
    onError: () => {
      setAlertVariant("danger");
      setAlertText("Error al eliminar la promoción");
    },
  });

  return (
    <BaseContainer>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        <h1
          css={{
            alignSelf: "center",
            marginTop: "2rem",
            textAlign: "center",
          }}
        >
          Promociones
        </h1>
        <Button
          onClick={() => navigate("/registrar-promocion")}
          css={{ marginTop: "2rem" }}
        >
          Crear Promoción
        </Button>
        <div
          css={{
            display: "flex",
            marginTop: "2rem",
            flexDirection: "column",
            alignItems: "stretch",
            gap: "1rem",
          }}
        >
          {promotions.map((promotion) => (
            <div
              key={promotion.id}
              css={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                padding: "1rem",
                border: "1px solid black",
                borderRadius: "1rem",
                backgroundColor: "rgb(245, 245, 245)",
              }}
            >
              <div>
                <b>{promotion.name}</b>
                <br/>
                {promotion.description}
              </div>
              <div>
                <Button
                  variant={"danger"}
                  onClick={() => promotionsDeleteMutation.mutate(promotion.id)}
                >
                  Eliminar
                </Button>
              </div>
            </div>
          ))}
          <Alert variant={alertVariant} show={alertText !== ""}>
            {alertText}
          </Alert>
        </div>
      </Container>
    </BaseContainer>
  );
}
