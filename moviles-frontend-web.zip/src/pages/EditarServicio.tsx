import React, { useEffect, useState } from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import { Alert, Spinner } from "react-bootstrap";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";

export { EditarServicio };

function EditarServicio(): React.ReactElement {
  const [loading, setLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const { id } = useParams();

  const categoriesQuery = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/categories/");
      return await response.json();
    },
  });

  const categories = categoriesQuery.data ?? [];

  const serviceQuery = useQuery({
    queryKey: ["service", id],
    queryFn: async () => {
      const response = await fetch(`http://localhost:8000/api/services/${id}/`);
      return await response.json();
    },
  });

  const service = serviceQuery.data;

  const employeesQuery = useQuery({
    queryKey: ["employees"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/employees/");
      return await response.json();
    },
  });

  const employees = employeesQuery.data ?? [];

  useEffect(() => {
    const form = document.getElementById("formEditService") as HTMLFormElement;
    if (service) {
      form.elements.namedItem("name").value = service.name;
      form.elements.namedItem("description").value = service.description;
      form.elements.namedItem("price").value = service.price;
      form.elements.namedItem("category").value = service.category;
      form.elements.namedItem("duration").value = service.duration;
      const selectedStaff = document.querySelector("#select-staff");
      for (let i = 0; i < selectedStaff.options.length; i++) {
        console.log(selectedStaff.options[i].selected)
        selectedStaff.options[i].selected =
          service.staff.indexOf(selectedStaff.options[i].value) >= 0;
      }
    }
  }, [service, employees]);

  async function handleEditService() {
    const form = document.getElementById("formEditService") as HTMLFormElement;
    const name = form.elements.namedItem("name").value;
    const description = form.elements.namedItem("description").value;
    const price = form.price.value;
    const category = form.category.value;
    const duration = form.duration.value;
    const selectedStaff = document.querySelectorAll(
      "#select-staff option:checked"
    );
    const staff = Array.from(selectedStaff).map((el) => el.value);
    const data = {
      name,
      description,
      price,
      category,
      duration,
      staff,
    };
    setLoading(true);
    try {
      const response = await fetch(
        `http://localhost:8000/api/services/${id}/`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }
      );
      if (response.status === 200) {
        setShowAlert(true);
      }
    } catch {
      /* empty */
    } finally {
      setLoading(false);
    }
  }

  return (
    <BaseContainer>
      <h1
        css={{
          alignSelf: "center",
          marginTop: "2rem",
        }}
      >
        Editar Servicio
      </h1>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        {loading && (
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        )}
        <Form id={"formEditService"}>
          <Form.Group className="mb-3" controlId="name">
            <Form.Label>Nombre</Form.Label>
            <Form.Control placeholder="Nombre" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="description">
            <Form.Label>Descripción</Form.Label>
            <Form.Control placeholder="Descripción" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="price">
            <Form.Label>Precio</Form.Label>
            <Form.Control placeholder="Precio" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="category">
            <Form.Label>Categoría</Form.Label>
            <Form.Select>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </Form.Select>
          </Form.Group>
          <Form.Group className="mb-3" controlId="staff">
            <Form.Label>Empleados</Form.Label>
            <Form.Select multiple id={"select-staff"}>
              {employees.map((employee) => (
                <option value={employee.id}>
                  {employee.name} {employee.lastName}
                </option>
              ))}
            </Form.Select>
          </Form.Group>
          <Form.Group className="mb-3" controlId="duration">
            <Form.Label>Duración</Form.Label>
            <Form.Control placeholder="Duración" />
          </Form.Group>

          <Button variant="primary" type="button" onClick={handleEditService}>
            Guardar
          </Button>
        </Form>
        {showAlert && (
          <Alert
            variant={"success"}
            css={{ marginTop: "2rem" }}
            dismissible
            onClose={() => setShowAlert(false)}
          >
            Servicio actualizado exitosamente
          </Alert>
        )}
      </Container>
    </BaseContainer>
  );
}
