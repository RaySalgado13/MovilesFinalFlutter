import React, { useEffect, useState } from "react";
import { BaseContainer } from "src/components/Common/BaseContainer";
import Container from "react-bootstrap/Container";
import { Alert } from "react-bootstrap";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Button from "react-bootstrap/Button";
import { useNavigate, useParams } from "react-router-dom";
import Form from "react-bootstrap/Form";

export { Reportes };

function getWeekNumber(d) {
  // Copy date so don't modify original
  d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  // Set to nearest Thursday: current date + 4 - current day number
  // Make Sunday's day number 7
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  // Get first day of year
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  // Calculate full weeks to nearest Thursday
  const weekNo = Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
  // Return array of year and week number
  return [d.getUTCFullYear(), weekNo];
}

function Reportes(): React.ReactElement {
  const [filterValue, setFilterValue] = useState("ALL");
  const [filterCategory, setFilterCategory] = useState("");
  const [filterService, setFilterService] = useState("");
  const [filterEmployee, setFilterEmployee] = useState("");
  const [filteredAgendas, setFilteredAgendas] = useState([]);

  const employeesQuery = useQuery({
    queryKey: ["employees"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/employees/");
      return await response.json();
    },
  });

  const servicesQuery = useQuery({
    queryKey: ["services"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/services/");
      return await response.json();
    },
  });

  const categoriesQuery = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/categories/");
      return await response.json();
    },
  });

  const agendaQuery = useQuery({
    queryKey: ["agenda"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/agenda/");
      return await response.json();
    },
  });

  const employees = employeesQuery.data ?? [];
  const services = servicesQuery.data ?? [];
  const agenda = agendaQuery.data ?? [];
  const categories = categoriesQuery.data ?? [];

  const filteredServices = filteredAgendas.map(a => {
    const s = services.find(s => s.id === a.service);
    return s;
  })

  useEffect(() => {
    const today = new Date().toISOString().slice(0, 10);
    const currentWeekNumber = getWeekNumber(new Date())[1];
    const monthNumber = new Date().getMonth() + 1;
    let newFilteredAgendas = [...agenda];
    switch (filterValue) {
      case "DAY":
        newFilteredAgendas = newFilteredAgendas.filter((a) => a.date === today);
        break;
      case "WEEK":
        newFilteredAgendas = newFilteredAgendas.filter(
          (a) => getWeekNumber(new Date(a.date))[1] === currentWeekNumber
        );
        break;
      case "QUINCENA":
        newFilteredAgendas = newFilteredAgendas.filter(
          (a) =>
            getWeekNumber(new Date(a.date))[1] === currentWeekNumber ||
            getWeekNumber(new Date(a.date))[1] === currentWeekNumber - 1
        );
        break;
      case "MONTH":
        newFilteredAgendas = newFilteredAgendas.filter(
          (a) => new Date(a.date).getMonth() + 1 === monthNumber
        );
        break;
      default:
        break;
    }
    if (filterCategory !== "") {
      const x = services.filter((s) => s.category === filterCategory);
      newFilteredAgendas = newFilteredAgendas.filter((a) =>
        x.some((s) => s.id === a.service)
      );
    }
    if (filterService !== "") {
      newFilteredAgendas = newFilteredAgendas.filter(
        (a) => a.service === filterService
      );
    }
    if (filterEmployee !== "") {
      newFilteredAgendas = newFilteredAgendas.filter(
        (a) => a.employee === filterEmployee
      );
    }
    setFilteredAgendas(newFilteredAgendas);
  }, [
    filterValue,
    agenda,
    employees,
    filterCategory,
    filterEmployee,
    filterService,
  ]);

  return (
    <BaseContainer>
      <h1
        css={{
          alignSelf: "center",
          marginTop: "2rem",
        }}
      >
        Reporte de Ventas
      </h1>
      <Container
        css={{
          maxWidth: "800px",
          marginTop: "1rem",
        }}
      >
        <div
          css={{
            display: "flex",
            marginTop: "2rem",
            flexDirection: "column",
            alignItems: "stretch",
            gap: "1rem",
          }}
        >
          <Form.Group className="mb-3" controlId="category">
            <Form.Label>Filtrar Por</Form.Label>
            <Form.Select
              onChange={(e) => {
                setFilterValue(e.target.value);
              }}
            >
              <option value={"All"}>Todos</option>
              <option value={"DAY"}>Día</option>
              <option value={"WEEK"}>Semana</option>
              <option value={"QUINCENA"}>Quincena</option>
              <option value={"MONTH"}>Mes</option>
            </Form.Select>
          </Form.Group>
          <Form.Group className="mb-3" controlId="category">
            <Form.Label>Filtrar Por Empleado</Form.Label>
            <Form.Select
              onChange={(e) => {
                setFilterEmployee(e.target.value);
              }}
            >
              <option value={""}>Todos</option>
              {employees.map((employee) => {
                return (
                  <option key={employee.id} value={employee.id}>
                    {employee.name}
                  </option>
                );
              })}
            </Form.Select>
          </Form.Group>

          <Form.Group className="mb-3" controlId="category">
            <Form.Label>Filtrar Por Categoria</Form.Label>
            <Form.Select
              onChange={(e) => {
                setFilterCategory(e.target.value);
              }}
            >
              <option value={""}>Todos</option>
              {categories.map((category) => {
                return (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                );
              })}
            </Form.Select>
          </Form.Group>

          <Form.Group className="mb-3" controlId="category">
            <Form.Label>Filtrar Por Servicio</Form.Label>
            <Form.Select
              onChange={(e) => {
                setFilterService(e.target.value);
              }}
            >
              <option value={""}>Todos</option>
              {services.map((service) => {
                return (
                  <option key={service.id} value={service.id}>
                    {service.name}
                  </option>
                );
              })}
            </Form.Select>
          </Form.Group>
          {filteredAgendas.map((agenda) => {
            const service = services.find(
              (service) => service.id === agenda.service
            );
            const employee = employees.find(
              (employee) => employee.id === agenda.employee
            );
            console.log(service);
            return (
              <div
                key={agenda.id}
                css={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  padding: "1rem",
                  border: "1px solid black",
                  borderRadius: "1rem",
                  backgroundColor: "rgb(245, 245, 245)",
                }}
              >
                <div>
                  <span>
                    <b>{service.name}</b>{" "}
                  </span>
                  <br />
                  <span>{employee.name}</span>
                  <br />
                  <span>${service.price}</span>
                  <br />
                  <span>{agenda.userEmail} </span>
                  <br />
                  <span>{agenda.date} </span>
                  <span>{agenda.time} </span>
                </div>
              </div>
            );
          })}
        </div>
        <div
          css={{
            marginTop: "2rem",
          }}
        >
          <span>
            <b>Total: </b>
          </span>
          <span>
            {filteredServices
              .map((s) => parseFloat(s.price))
              .reduce((partialSum, a) => partialSum + a, 0)}
          </span>
        </div>
      </Container>
    </BaseContainer>
  );
}
