import { createBrowserRouter } from "react-router-dom";
import { Home } from "src/pages/Home.tsx";
import { RegistrarEmpleado } from "./pages/RegistrarEmpleado";
import { Login } from "src/pages/Login.tsx";
import { RegistrarCategoria } from "src/pages/RegistrarCategoria.tsx";
import { RegistrarServicio } from "src/pages/RegistrarServicio.tsx";
import { Empleados } from "src/pages/Empleados.tsx";
import { EditarEmpleado } from "src/pages/EditarEmpleado.tsx";
import { Servicios } from "src/pages/Servicios.tsx";
import { EditarServicio } from "src/pages/EditarServicio.tsx";
import { EditarCategoria } from "src/pages/EditarCategoria.tsx";
import { AgendaCaja } from "src/pages/AgendaCaja.tsx";
import { AgendaIndividual } from "src/pages/AgendaIndividual.tsx";
import { Reportes } from "src/pages/Reportes.tsx";
import { Promociones } from "src/pages/Promociones.tsx";
import { RegistrarPromocion } from "src/pages/RegistrarPromocion.tsx";

export { router };

const router = createBrowserRouter([
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/registrar-empleado",
    element: <RegistrarEmpleado />,
  },
  {
    path: "/registrar-categoria",
    element: <RegistrarCategoria />,
  },
  {
    path: "/registrar-servicio",
    element: <RegistrarServicio />,
  },
  {
    path: "/registrar-promocion",
    element: <RegistrarPromocion />,
  },
  {
    path: "/editar-empleado/:id",
    element: <EditarEmpleado />,
  },
  {
    path: "/editar-servicio/:id",
    element: <EditarServicio />,
  },
  {
    path: "/editar-categoria/:id",
    element: <EditarCategoria />,
  },
  {
    path: "/empleados",
    element: <Empleados />,
  },
  {
    path: "/servicios",
    element: <Servicios />,
  },
  {
    path: "/agenda-caja",
    element: <AgendaCaja />,
  },
  {
    path: "/agenda/:id",
    element: <AgendaIndividual />,
  },
  {
    path: "/reportes",
    element: <Reportes />,
  },
  {
    path: "/promociones",
    element: <Promociones />,
  },
  {
    path: "/login",
    element: <Login />,
  },
]);
