import React, { useEffect, useState } from "react";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import { Container } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";

export { BaseContainer };

interface BaseContainerProps {
  children: React.ReactNode;
  className?: string;
}

function BaseContainer({
  children,
  className,
}: BaseContainerProps): React.ReactElement {
  const navigate = useNavigate();
  const [userType, setUserType] = useState("");
  const [userEmail, setUserEmail] = useState("");

  useEffect(() => {
    const x = localStorage.getItem("userType");
    const y = localStorage.getItem("userEmail");
    setUserType(x ?? "");
    setUserEmail(y ?? "");
  }, []);

  const employeesQuery = useQuery({
    queryKey: ["employees"],
    queryFn: async () => {
      const response = await fetch("http://localhost:8000/api/employees/");
      return await response.json();
    },
  });

  const employees = employeesQuery.data ?? [];

  const employeeId =
    employees.find((employee: any) => employee.email === userEmail)?.id ?? "";

  return (
    <Container
      fluid
      className={className}
      css={{
        display: "flex",
        justifyContent: "flex-start",
        alignItems: "stretch",
        flexDirection: "column",
        backgroundColor: "rgb(245, 245, 250)",
        minHeight: "100%",
        paddingBottom: "2rem",
      }}
    >
      {userType === "Gerente" && (
        <Navbar bg="light" expand="lg">
          <Container>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <div
                css={{
                  display: "flex",
                  width: "100%",
                  justifyContent: "space-between",
                }}
              >
                <Nav className="mr-auto">
                  <Nav.Link onClick={() => navigate("/")}>Inicio</Nav.Link>
                  <Nav.Link onClick={() => navigate("/agenda-caja")}>
                    Agendas
                  </Nav.Link>
                  <Nav.Link onClick={() => navigate("/servicios")}>
                    Servicios y Categorias
                  </Nav.Link>
                  <Nav.Link onClick={() => navigate("/empleados")}>
                    Empleados
                  </Nav.Link>
                  <Nav.Link onClick={() => navigate("/reportes")}>
                    Reportes
                  </Nav.Link>
                  <Nav.Link onClick={() => navigate("/promociones")}>
                    Promociones
                  </Nav.Link>
                </Nav>
                <div
                  css={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {userEmail}
                </div>
              </div>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      )}
      {userType === "Caja" && (
        <Navbar bg="light" expand="lg">
          <Container>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <div
                css={{
                  display: "flex",
                  width: "100%",
                  justifyContent: "space-between",
                }}
              >
                <Nav className="mr-auto">
                  <Nav.Link onClick={() => navigate("/")}>Inicio</Nav.Link>
                  <Nav.Link onClick={() => navigate("/agenda-caja")}>
                    Agendas
                  </Nav.Link>
                  <Nav.Link onClick={() => navigate("/reportes")}>
                    Reportes
                  </Nav.Link>
                </Nav>
                <div
                  css={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {userEmail}
                </div>
              </div>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      )}
      {userType === "Empleado" && (
        <Navbar bg="light" expand="lg">
          <Container>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <div
                css={{
                  display: "flex",
                  width: "100%",
                  justifyContent: "space-between",
                }}
              >
                <Nav className="mr-auto">
                  <Nav.Link onClick={() => navigate("/")}>Inicio</Nav.Link>
                  <Nav.Link onClick={() => navigate(`/agenda/${employeeId}`)}>
                    Agendas
                  </Nav.Link>
                </Nav>
                <div
                  css={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {userEmail}
                </div>
              </div>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      )}

      {children}
    </Container>
  );
}
