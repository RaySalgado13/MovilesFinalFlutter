import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

export { app, auth };

const firebaseConfig = {
  apiKey: "AIzaSyCTjscTTcswRx4fXxKqYDiC4t2XA_D3s8A",
  authDomain: "fir-moviles-c2a13.firebaseapp.com",
  projectId: "fir-moviles-c2a13",
  storageBucket: "fir-moviles-c2a13.appspot.com",
  messagingSenderId: "1055807757005",
  appId: "1:1055807757005:web:6eb95f59d8bfc67c4b2784",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
