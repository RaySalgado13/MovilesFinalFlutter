class Employee{

  Employee({
    required this.id,
    required this.name,
    required this.lastName,
    required this.curp,
    required this.phone,

  });

  final String id;
  final String name;
  final String lastName;
  final String curp;
  final String phone;

  @override
  bool operator ==(Object other){
    return other is Employee && this.id == other.id;
  }
}