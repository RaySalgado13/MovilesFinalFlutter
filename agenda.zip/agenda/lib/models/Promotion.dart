class Promotion{
  Promotion({
    required this.id,
    required this.name,
    required this.description,
  });

  final String id;
  final String name;
  final String description;

}