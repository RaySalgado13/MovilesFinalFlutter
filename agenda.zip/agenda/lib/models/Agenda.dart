class Agenda{
  Agenda({
    required this.id,
    required this.date,
    required this.time,
    required this.userEmail,
    //required this.name,
    required this.employee,
    required this.service,
  });

  final String id;
  final String date;
  final String time;
  //final String name;
  final String userEmail;
  final String employee;
  final String service;
}