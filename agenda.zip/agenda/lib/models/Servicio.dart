import 'package:agenda/models/Employee.dart';

class Servicio {
  Servicio({
    required this.id,
    required this.name,
    required this.description,
    required this.duration,
    required this.price,
    required this.staff,
    required this.category,
  });

  final String id;
  final String name;
  final String description;
  final String duration;
  final double price;
  final List<Employee> staff;
  final String category;

}