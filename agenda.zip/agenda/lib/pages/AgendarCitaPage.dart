import 'package:table_calendar/table_calendar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'ConfirmarCitaPage.dart';
import 'package:agenda/models/Servicio.dart';
import 'package:agenda/models/Employee.dart';
import 'package:agenda/models/Agenda.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AgendarCitaPage extends StatefulWidget {
  AgendarCitaPage(
      {super.key,
      required this.selected_employee,
      required this.selected_service});

  final Servicio selected_service;
  final Employee selected_employee;
  List<Agenda> agenda = [];

  @override
  State<AgendarCitaPage> createState() => _AgendarCitaPageState();
}

class _AgendarCitaPageState extends State<AgendarCitaPage> {
  DateTime _selectedDate = DateTime.now();
  DateTime _focusedDay = DateTime.now();

  Stream agendaCollectionStream = FirebaseFirestore.instance
      .collection('agenda')
      .snapshots();

  @override
  Widget build(BuildContext context) {
    DateTime date = DateTime.now();

    agendaCollectionStream.listen((event) {
      widget.agenda.clear();
      List<Agenda> x = [];
      for (var i = 0; i < event.docs.length; i++) {
        var doc = event.docs[i].data();
        x.add(Agenda(
          id: event.docs[i].reference.id,
          date: doc['date'],
          time: doc['time'],
          userEmail: doc['userEmail'],
          //name: doc['name'],
          employee: doc['employee'],
          service: doc['service'],
        ));
      }
      x = x.where((element) {
        return element.employee == widget.selected_employee.id && element.service == widget.selected_service.id;
      }).toList();

      widget.agenda.addAll(x);
      setState(() {
      });
    });

    print(widget.agenda);

    return Scaffold(
        appBar: AppBar(
          title: Text('Servicios'),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF3A6186),
                  Color(0xFF89253E),
                ],
              ),
            ),
          ),
        ),
        body: Column(
          children: [
            TableCalendar(
              firstDay: DateTime(DateTime.now().year - 1),
              lastDay: DateTime(DateTime.now().year + 1),
              focusedDay: _selectedDate,
              selectedDayPredicate: (day) => isSameDay(_selectedDate, day),
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDate = selectedDay;
                  _focusedDay = selectedDay;
                });
              },
            ),
            Row(
              children: [
                Padding(padding: EdgeInsets.all(16)),
                TextButton(
                    onPressed: () {
                      showTimePicker(
                          context: context,
                          initialTime: TimeOfDay.fromDateTime(_selectedDate))
                          .then((value) {
                            setState(() {
                              _selectedDate = DateTime(_selectedDate.year, _selectedDate.month, _selectedDate.day, value!.hour, value.minute);
                            });
                          });
                    },
                    child: const Text('Hora')),
              ],
            ),
            GradientButton(
              text: 'Confirmar cita',
              gradientColors: [Color(0xFF3A6186), Color(0xFF89253E)],
              onPressed: () {



                var time = TimeOfDay.fromDateTime(_selectedDate);
                var minutes = time.hour * 60 + time.minute;

                print(time);
                //Iterar agendas
                for(var i = 0; i < widget.agenda.length; i++){
                  var timestring = widget.agenda[i].time;
                  var timeagenda = TimeOfDay(hour: int.parse(timestring.split(':')[0]), minute: int.parse(timestring.split(':')[1]));
                  var minutes_start = timeagenda.hour * 60 + timeagenda.minute;
                  var minutes_end = minutes_start + int.parse(widget.selected_service.duration);

                  print(timestring);
                  print(timeagenda);

                  if(minutes >= minutes_start && minutes <= minutes_end){
                    var snackBar = SnackBar(content: Text('Esta hora ya está reservada'));
                    ScaffoldMessenger.of(context).showSnackBar(snackBar);
                    return;
                  }
                }

                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ConfirmarCitaPage(
                          selected_service: widget.selected_service,
                          selected_employee: widget.selected_employee,
                          date: _selectedDate.toIso8601String().substring(0,10),
                          time: '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}',
                        )));
              },
            ),
          ],
        ));
  }
}

class GradientButton extends StatelessWidget {
  final String text;
  final List<Color> gradientColors;
  final VoidCallback onPressed;

  GradientButton(
      {required this.text,
      required this.gradientColors,
      required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: gradientColors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(4.0),
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          primary: Colors.transparent,
          elevation: 0.0,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.0)),
        ),
        child: Text(text),
      ),
    );
  }
}
