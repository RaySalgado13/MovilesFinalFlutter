import 'package:agenda/pages/HomePage.dart';
import 'package:firebase_auth/firebase_auth.dart' hide EmailAuthProvider;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'ServiciosPage.dart';
import 'package:agenda/models/Servicio.dart';
import 'package:agenda/models/Employee.dart';
import 'package:agenda/models/Servicio.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class ConfirmarCitaPage extends StatefulWidget{
  ConfirmarCitaPage({
    super.key,
    required this.selected_service,
    required this.selected_employee,
    required this.date,
    required this.time
  });

  final Servicio selected_service;
  final Employee selected_employee;
  final String date;
  final String time;


  @override
  State<ConfirmarCitaPage> createState() => _ConfirmarCitaPageState();
}

class Cita {
  Cita({
    required this.titulo,
    required this.descripcion,
    required this.dia,
    required this.hora,
    required this.staff
  });
  final String titulo;
  final String descripcion;
  final DateTime dia;
  final TimeOfDay hora;
  final String staff;
}

class _ConfirmarCitaPageState extends State<ConfirmarCitaPage> {
  List<Cita> Citas = [
    Cita(
        titulo: "Corte de cabello",
        descripcion: "Puede variar en estilo y longitud dependiendo de las preferencias personales y de la moda actual. Corte a gusto del cliente con máquina o tijera.",
        dia: DateTime(2023, 5, 15, 10, 0),
        hora: TimeOfDay(hour: 12, minute: 00),
        staff: "Angela torres."
    ),
  ];

  CollectionReference agendaCollection = FirebaseFirestore.instance.collection('agenda');

  @override
  Widget build(BuildContext context) {

    return Scaffold(
          appBar: AppBar(
            title: Text('Confirmar cita'),
            flexibleSpace: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF3A6186),
                    Color(0xFF89253E),
                  ],
                ),
              ),
            ),
          ),
          body: ListView.builder(
              itemCount: Citas.length,
              itemBuilder: (context, index){
                return Container(
                  margin: const EdgeInsets.all(16.0),
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                      color: Colors.grey[100],
                      borderRadius: BorderRadius.circular(8.0)
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.selected_service.name,
                        style: const TextStyle(
                          fontSize: 20.0,
                        ),
                      ),
                      Text(widget.selected_service.description,
                        style: const TextStyle(
                          fontSize: 15.0,
                        ),
                      ),
                      Padding(padding: EdgeInsets.only(top: 16)),
                      Row(
                        children: [
                          Material(
                            borderRadius: BorderRadius.circular(30),
                            elevation: 5,
                            color: Color(0xFFCC9BA7),
                            child: Container(
                              width: 80,
                              height: 15,
                              child: Center(
                                child: Text(
                                  widget.selected_employee.name + " " + widget.selected_employee.lastName,
                                  style: TextStyle(fontSize: 11, color: Color(0xFF89253E), fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(padding: EdgeInsets.only(top: 16)),
                      Row(
                        children: [
                          Material(
                            borderRadius: BorderRadius.circular(30),
                            elevation: 5,
                            color: Color(0xFF97C0B5),
                            child: Container(
                              width: 65,
                              height: 15,
                              child: Center(
                                child: Text(
                                  // Citas[index].dia.day.toString() + "/" + Citas[index].dia.month.toString() + "/" + Citas[index].dia.year.toString(),
                                  widget.date,
                                  style: TextStyle(fontSize: 11, color: Color(0xFF258965), fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ),
                          Padding(padding: EdgeInsets.all(16)),
                          Material(
                            borderRadius: BorderRadius.circular(30),
                            elevation: 5,
                            color: Color(0xFFA0AFC0),
                            child: Container(
                              width: 65,
                              height: 15,
                              child: Center(
                                child: Text(
                                  //Citas[index].hora.hour.toString() + ":" + Citas[index].hora.minute.toString() + " hrs",
                                  widget.time+" hrs",
                                  style: TextStyle(fontSize: 11, color: Color(0xFF3A6186), fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(padding: EdgeInsets.all(16)),
                      Column(
                        children: [
                          Center(
                            child: Column(
                              children: [
                                Padding(padding: EdgeInsets.all(16)),
                                GradientButton(
                                  text: 'Confirmar cita',
                                  gradientColors: [Color(0xFF3A6186), Color(0xFF89253E)],
                                  onPressed: () {
                                    agendaCollection.add({
                                      'date': widget.date,
                                      'time': widget.time,
                                      'userEmail': FirebaseAuth.instance.currentUser?.email,
                                      'employee': widget.selected_employee.id,
                                      'service' : widget.selected_service.id
                                    })
                                    .then((value) {
                                      print('Servicio agendado');
                                      Navigator.push(context, MaterialPageRoute(builder: (context) => Confirmacion()));
                                    })
                                    .catchError((error) => print('Servicio agendado'));
                                  },
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                );
              }
          )
    );
  }
}

class Confirmacion extends StatelessWidget{

  @override

  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Confirmacion'),
        flexibleSpace: Container(

          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF3A6186),
                Color(0xFF89253E),
              ],
            ),
          ),
        ),
      ),
      body: Container(
        margin: const EdgeInsets.all(16.0),
        padding: const EdgeInsets.all(16.0),
        decoration: BoxDecoration(
            color: Colors.grey[100],
            borderRadius: BorderRadius.circular(8.0)
        ),
        child: Center(
          child: Column(
            children: [
              Text("Se ha agendado su cita exitosamente"),
              Padding(padding: EdgeInsets.only(top: 16)),
              GradientButton(
                text: 'Ir a inicio',
                gradientColors: [Color(0xFF3A6186), Color(0xFF89253E)],
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        ),
      )
    );
  }
}