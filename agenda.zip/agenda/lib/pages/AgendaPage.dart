import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'InicioPage.dart';
import 'ServiciosPage.dart';
import 'package:agenda/components/GradientButton.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:agenda/models/Servicio.dart';
import 'package:agenda/models/Employee.dart';
import 'package:agenda/models/Agenda.dart';
import 'package:firebase_auth/firebase_auth.dart' hide EmailAuthProvider;
import 'package:collection/collection.dart';



class AgendaPage extends StatefulWidget {

  List<Agenda> agenda = [];
  final List<Servicio> current_services = [];
  final List<Employee> current_employees = [];
  @override
  State<AgendaPage> createState() => _AgendaPageState();
}

class Appoinment {
  final String id;
  final String day;
  final String activity;
  final DateTime dateTime;
  final String clientName;
  final double price;

  Appoinment({
    required this.id,
    required this.day,
    required this.activity,
    required this.dateTime,
    required this.clientName,
    required this.price
  });
}

class _AgendaPageState extends State<AgendaPage> {
  final List<Appoinment> appointments = [];
  final List<Appoinment> appointments_days = [];

  Stream agendaCollectionStream = FirebaseFirestore.instance.collection('agenda').snapshots();
  Stream employeesCollectionStream = FirebaseFirestore.instance.collection('employees').snapshots();
  Stream servicesCollectionStream = FirebaseFirestore.instance.collection('services').snapshots();


  double calculateTotal(String day, List<Appoinment> appointments){
    double total = 0;
    for(var i=0; i<appointments.length; i++){
      if(appointments[i].day == day){
        total = total + appointments[i].price;
      }
    }

    return total;
  }

  @override
  Widget build(BuildContext context) {
    employeesCollectionStream.listen((event) {
      widget.current_employees.clear();
      List<Employee> x = [];
      for (var i = 0; i < event.docs.length; i++) {
        var doc = event.docs[i].data();
        x.add(Employee(
          id: event.docs[i].reference.id,
          name: doc['name'],
          lastName: doc['name'],
          curp: doc['curp'],
          phone: doc['phone'],
        ));
      }
      widget.current_employees.addAll(x);

      setState(() {});

    });

    servicesCollectionStream.listen((event) {
      widget.current_services.clear();
      List<Servicio> x = [];
      for (var i = 0; i < event.docs.length; i++) {
        var doc = event.docs[i].data();
        List<Employee> employees = [];
        List<String> employees_id = List<String>.from(doc['staff']);
        for(var j = 0; j < employees_id.length; j++){
          var e = widget.current_employees.firstWhereOrNull((element) => element.id == employees_id[j]);
          if(e != null){
            employees.add(e);
          }
        }
        x.add(Servicio(
            id: event.docs[i].reference.id,
            name: doc['name'],
            description: doc['description'],
            duration: doc['duration'],
            price: double.parse(doc['price']),
            category: doc['category'],
            staff: employees));

      }
      widget.current_services.addAll(x);

      setState(() {});

    });

    agendaCollectionStream.listen((event) {
      widget.agenda.clear();
      appointments.clear();
      appointments_days.clear();
      List<Agenda> x = [];
      for (var i = 0; i < event.docs.length; i++) {
        var doc = event.docs[i].data();

        var e = widget.current_employees.firstWhereOrNull((element) => element.id == doc['employee']);
        var s = widget.current_services.firstWhereOrNull((element) => element.id == doc['service']);

        if(e != null && s != null && FirebaseAuth.instance.currentUser?.email == doc['userEmail']){
          appointments.add(
              Appoinment(id: event.docs[i].reference.id ,day: doc['date'], activity: s.name, dateTime: DateTime.parse('${doc['date']}T${doc['time']}'), clientName: e.name, price: s.price)
          );
          var a = appointments_days.firstWhereOrNull((element) => element.day == doc['date']);
          if(a == null){
            appointments_days.add(
                Appoinment(id: event.docs[i].reference.id, day: doc['date'], activity: s.name, dateTime: DateTime.parse('${doc['date']}T${doc['time']}'), clientName: e.name, price: s.price)
            );
          }
        }
      }

      setState(() {
      });
    });

    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Próximas citas'),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF3A6186),
                  Color(0xFF89253E),
                ],
              ),
            ),
          ),
        ),
        body: ListView.builder(
            itemCount: appointments_days.length,
            itemBuilder: (context, index) {
              return Container(
                margin: const EdgeInsets.all(16.0),
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(8.0)
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                     appointments_days[index].day,
                      style: const TextStyle(
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold
                      ),
                    ),
                    const SizedBox(height: 16.0),
                    Column(
                      children: appointments
                          .where((element) => element.day == appointments_days[index].day)
                          .map(
                              (appointment) => Container(
                                padding: EdgeInsets.all(8.0),
                                decoration: BoxDecoration(
                                  // border: Border.all(color: Colors.green),
                                  borderRadius: BorderRadius.circular(4.0)
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      appointment.activity,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold
                                      ),
                                    ),
                                    SizedBox(height: 4.0),
                                    Text(
                                      '${appointment.dateTime.day}/${appointment.dateTime.month}/${appointment.dateTime.year} - ${appointment.dateTime.hour.toString().padLeft(2, '0')}:${appointment.dateTime.minute.toString().padLeft(2, '0')}',
                                      style: TextStyle(
                                        fontSize: 12.0,
                                        color: Colors.grey,
                                      ),
                                    ),
                                    SizedBox(height: 8.0),
                                    Row(
                                      mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                      children: [
                                        Material(
                                          borderRadius: BorderRadius.circular(30),
                                          elevation: 5,
                                          color: Color(0xFFCC9BA7),
                                          child: Container(
                                            width: 65,
                                            height: 15,
                                            child: Center(
                                              child: Text(
                                                appointment.clientName,
                                                style: TextStyle(fontSize: 11, color: Color(0xFF89253E), fontWeight: FontWeight.bold),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Material(
                                          borderRadius: BorderRadius.circular(30),
                                          elevation: 5,
                                          color: Color(0xFF97C0B5),
                                          child: Container(
                                            width: 65,
                                            height: 15,
                                            child: Center(
                                              child: Text(
                                                '\$${appointment.price.toStringAsFixed(2)}',
                                                style: TextStyle(fontSize: 11, color: Color(0xFF258965), fontWeight: FontWeight.bold),
                                              ),
                                            ),
                                          ),
                                        ),
                                        // Text(
                                        //   appointment.clientName,
                                        //   style: TextStyle(
                                        //     color: Colors.red
                                        //   ),
                                        // ),
                                        // Text(
                                        //   '\$${appointment.price.toStringAsFixed(2)}',
                                        //   style: TextStyle(
                                        //     color: Colors.green
                                        //   ),
                                        // ),
                                      ],
                                    ),
                                    SizedBox(height: 16.0),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        ElevatedButton(
                                          style: ButtonStyle(
                                            backgroundColor: MaterialStateProperty.all<Color>(Color(0xFF89253E)),
                                          ),
                                          onPressed: () {
                                            showDialog(
                                              context: context,
                                              builder: (BuildContext context){
                                                return AlertDialog(
                                                  title: Text('Confirmación de cancelación'),
                                                  content: Text('¿Estás seguro que quieres cancelar la cita?'),
                                                  actions: [
                                                    // TextButton(
                                                    //     onPressed: () {
                                                    //       Navigator.of(context).pop();
                                                    //     },
                                                    //     child: Text('Regresar')
                                                    // ),
                                                    ElevatedButton(
                                                      style: ButtonStyle(
                                                        backgroundColor: MaterialStateProperty.all<Color>(Color(0xFFFFFFFF)),
                                                      ),
                                                      onPressed: (){
                                                        Navigator.of(context).pop();
                                                      },
                                                      child: Text('Regresar', style: TextStyle(color: Colors.black),),
                                                    ),
                                                    // TextButton(
                                                    //     onPressed: () {
                                                    //       // Codigo para cancelar cita
                                                    //       Navigator.of(context).pop();
                                                    //     },
                                                    //     child: Text('Cancelar')
                                                    // ),
                                                    ElevatedButton(
                                                      style: ButtonStyle(
                                                        backgroundColor: MaterialStateProperty.all<Color>(Color(0xFFCC9BA7)),
                                                      ),
                                                      onPressed: (){
                                                        // Codigo para cancelar cita
                                                        FirebaseFirestore.instance.collection('agenda').doc(appointment.id).delete()
                                                        .then((value) => Navigator.of(context).pop());
                                                      },
                                                      child: Text('Cancelar', style: TextStyle(color: Color(0xFF89253E)),),
                                                    ),
                                                  ],
                                                );
                                              },
                                            );
                                          },
                                          child: Text('Cancelar'),

                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                            ).toList(),
                    ),
                    SizedBox(height: 16.0),
                    Text(
                      'Total',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 4.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Material(
                          borderRadius: BorderRadius.circular(30),
                          elevation: 5,
                          color: Color(0xFFA0AFC0),
                          child: Container(
                            width: 65,
                            height: 15,
                            child: Center(
                              child: Text(
                                '\$${calculateTotal(appointments_days[index].day, appointments).toStringAsFixed(2)}',
                                style: TextStyle(fontSize: 11, color: Color(0xFF3A6186), fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                        ),
                        // Text(
                        //   'Total: \$${calculateTotal(appointments[index].price)}',
                        //   style: TextStyle(
                        //     fontWeight: FontWeight.bold
                        //   ),
                        // ),

                      ],
                    ),
                  ],
                ),
              );
            }),
      ),


    );
  }

}


class Cancelacion extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
        appBar: AppBar(
          title: Text('Confirmacion'),
          flexibleSpace: Container(

            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF3A6186),
                  Color(0xFF89253E),
                ],
              ),
            ),
          ),
        ),
        body: Container(
          margin: const EdgeInsets.all(16.0),
          padding: const EdgeInsets.all(16.0),
          decoration: BoxDecoration(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(8.0)
          ),
          child: Center(
            child: Column(
              children: [
                Text("Su cita ha sido cancelada exitosamente"),
                Padding(padding: EdgeInsets.only(top: 16)),
                GradientButton(
                  text: 'Ir a inicio',
                  gradientColors: [Color(0xFF3A6186), Color(0xFF89253E)],
                  onPressed: () {
                    Navigator.push(
                        context, MaterialPageRoute(builder: (context) => InicioPage())
                    );
                  },
                ),
              ],
            ),
          ),
        )
    );
  }
}

