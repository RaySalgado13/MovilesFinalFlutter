import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:agenda/models/Promotion.dart';


class PromocionesPage extends StatefulWidget {

  List<Promotion> promotions = [];
  @override
  State<PromocionesPage> createState() => _PromocionesPageState();
}

class Promo {
  Promo({
    required this.titulo,
    required this.descripcion,
    required this.lugar
  });
  final String titulo;
  final String descripcion;
  final String lugar;
}

class _PromocionesPageState extends State<PromocionesPage> {
  List<Promo> promociones = [
    Promo(
        titulo: "Corte de cabello gratis",
        descripcion: "Por el dia internacional del peluquero ell dia de hoy todos los cortes sencillos tienen un 100% de descuento",
        lugar: "Barbería Capital"
    ),
    Promo(
        titulo: "Corte de cabello gratis",
        descripcion: "Por el dia internacional del peluquero ell dia de hoy todos los cortes sencillos tienen un 100% de descuento",
        lugar: "Barbería Capital"
    ),
    Promo(
        titulo: "Corte de cabello gratis",
        descripcion: "Por el dia internacional del peluquero ell dia de hoy todos los cortes sencillos tienen un 100% de descuento",
        lugar: "Barbería Capital"
    ),
    Promo(
        titulo: "Corte de cabello gratis",
        descripcion: "Por el dia internacional del peluquero ell dia de hoy todos los cortes sencillos tienen un 100% de descuento",
        lugar: "Barbería Capital"
    ),
    Promo(
        titulo: "Corte de cabello gratis",
        descripcion: "Por el dia internacional del peluquero ell dia de hoy todos los cortes sencillos tienen un 100% de descuento",
        lugar: "Barbería Capital")
  ];


  Stream promotionsCollectionStream = FirebaseFirestore.instance.collection('promotions').snapshots();

  @override
  Widget build(BuildContext context) {

    promotionsCollectionStream.listen((event) {
      widget.promotions.clear();
      List<Promotion> x = [];
      for (var i = 0; i < event.docs.length; i++) {
        var doc = event.docs[i].data();
        x.add(Promotion(
          id: event.docs[i].reference.id,
          name: doc['name'],
          description: doc['description'],
        ));
      }
      widget.promotions.addAll(x);

      setState(() {});

    });

    print(widget.promotions);

    return MaterialApp(
      home: Scaffold(
          appBar: AppBar(
            title: Text('Promociones'),
            flexibleSpace: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF3A6186),
                    Color(0xFF89253E),
                  ],
                ),
              ),
            ),
          ),
          body: ListView.builder(
              itemCount: widget.promotions.length,
              itemBuilder: (context, index){
                return Container(
                  margin: const EdgeInsets.all(16.0),
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(8.0)
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.promotions[index].name.toString(),
                        style: const TextStyle(
                          fontSize: 20.0,
                            fontWeight: FontWeight.w500
                        ),
                      ),
                      Divider(),
                      Text(widget.promotions[index].description.toString(),
                        style: const TextStyle(
                          fontSize: 15.0,
                        ),
                      ),
                      Padding(padding: EdgeInsets.all(4)),

                    ],
                  ),
                );
              }
          )
      ),
    );
  }
}
class GradientButtonProm extends StatelessWidget {
  final String text;
  final List<Color> gradientColors;
  final VoidCallback onPressed;

  GradientButtonProm({required this.text, required this.gradientColors, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: gradientColors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(4.0),
      ),
      child: ElevatedButton(
        onPressed: onPressed,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(text),
              SizedBox(
              ),
              Icon(
                Icons.arrow_circle_right_outlined,
              ),
            ],
          ),
        style: ElevatedButton.styleFrom(
          primary: Colors.transparent,
          elevation: 0.0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.0)),
        ),
      ),
    );
  }
}