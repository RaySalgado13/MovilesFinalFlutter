import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Inicio {
  Inicio({
    required this.servicio,
    required this.servidor,
    required this.fecha,
    required this.hora,
    required this.costo,
    required this.descripcion,
  });

  final String servicio;
  final String servidor;
  final DateTime fecha;
  final DateTime hora;
  final double costo;
  final String descripcion;
}

final String proximaCitaFecha = '30 de mayo de 2023';
final String hora = '';
final String servicio = 'Bienvenido de vuelta';
final String descripcion = "";
final String servidor = '';
final double costo = 50.0;

final String? current_user = FirebaseAuth.instance.currentUser?.email;

class InicioPage extends StatelessWidget {
  final List<Inicio> ultimos_servicios = [
    Inicio(
      servicio: 'Corte de pelo',
      descripcion: "Puede variar en estilo y longitud dependiendo de las preferencias personales y de la moda actual. Corte a gusto del cliente con máquina o tijera.",
      servidor: 'Ana María',
      fecha: DateTime(2023, 5, 15),
      hora: DateTime(2023, 5, 15, 10),
      costo: 50.0,
    ),
    Inicio(
      servicio: 'Tinte de cabello',
      servidor: 'Erick Filiberto',
      descripcion: "Distintos tipos de colores, degradados, uniformes o decolorados.",
      fecha: DateTime(2023, 5, 15),
      hora: DateTime(2023, 5, 15, 10, 00),
      costo: 30.0,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Inicio'),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF3A6186),
                Color(0x3589253E),
              ],
            ),
          ),
        ),
        toolbarHeight: 100,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Container(
            margin: const EdgeInsets.only(bottom: 16.0),
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                Padding(padding: EdgeInsets.all(10)),
                Text(
                  servicio,
                  style: const TextStyle(
                    fontSize: 20.0,
                  ),
                ),
                Row(
                  children: [
                   Text(current_user!,style: const TextStyle(
                    fontSize: 10.0,
                    ))
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
