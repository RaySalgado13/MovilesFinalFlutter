import 'package:agenda/authentication/authentication.dart';
import 'package:flutter/material.dart';
import 'InicioPage.dart';
import 'pages.dart';
import 'package:firebase_auth/firebase_auth.dart'
    hide EmailAuthProvider, PhoneAuthProvider;

class HomePage extends StatefulWidget {
  const HomePage({
    super.key,
    required this.loggedIn,
    required this.signOut
  });

  final bool loggedIn;
  final void Function() signOut;
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    InicioPage(),
    ServiciosPage(),
    AgendaPage(),
    PromocionesPage(),
  ];

  @override
  Widget build(BuildContext context) {
    if(widget.loggedIn){
      return Scaffold(
        // appBar: AppBar(
        //   title: Text('App'),
        //   leading: const CircleAvatar(
        //     child: Icon(Icons.person),
        //   ),
        // ),

        body: _screens[_currentIndex],
        bottomNavigationBar: BottomNavigationBar(
          fixedColor: Color(0xff313133),
          unselectedItemColor: Color(0xffc2c4ce),
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Inicio',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.border_all_rounded),
              label: 'Servicios',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.event_note),
              label: 'Agenda',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.discount),
              label: 'Promociones',
            ),
          ],
        ),
      );
    }
    else{
      return const Authentication();
    }
  }
}