import 'package:agenda/models/Employee.dart';
import 'package:flutter/cupertino.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'AgendarCitaPage.dart';
import 'package:agenda/models/Servicio.dart';
import 'package:agenda/models/Employee.dart';
import 'package:collection/collection.dart';

List<String> employees_list = [];

class DropdownButtonExample extends StatefulWidget {
  const DropdownButtonExample({
    super.key,
    required this.staff_list,
    required this.callback
  });

  final List<Employee> staff_list;
  final void Function(Employee?) callback;

  @override
  State<DropdownButtonExample> createState() => _DropdownButtonExampleState();
}

class _DropdownButtonExampleState extends State<DropdownButtonExample> {
  Employee? dropdownValue = null;

  @override
  Widget build(BuildContext context) {
    return DropdownButton<Employee>(
      value: dropdownValue,
      icon: const Icon(Icons.arrow_downward),
      elevation: 16,
      style: const TextStyle(color: Colors.green),
      underline: Container(
        height: 2,
        color: Colors.green,
      ),
      onChanged: (Employee? value) {
        // This is called when the user selects an item.
        widget.callback(value);
        setState(() {
          dropdownValue = value!;
        });
      },
      items: widget.staff_list.map<DropdownMenuItem<Employee>>((Employee value) {
        return DropdownMenuItem<Employee>(
          value: value,
          child: Text(value.name),
        );
      }).toList(),
    );
  }
}


class ServiciosPage extends StatefulWidget {
  final List<Servicio> current_services = [];
  final List<Employee> current_employees = [];

  @override
  State<ServiciosPage> createState() => _ServiciosPageState();
}

class _ServiciosPageState extends State<ServiciosPage> {

  Employee? selected_employee = null;

  Stream employeesCollectionStream = FirebaseFirestore.instance.collection('employees').snapshots();
  Stream collectionStream = FirebaseFirestore.instance.collection('services').snapshots();

  @override
  Widget build(BuildContext context) {



    employeesCollectionStream.listen((event) {
      widget.current_employees.clear();
      List<Employee> x = [];
      for (var i = 0; i < event.docs.length; i++) {
        var doc = event.docs[i].data();
        x.add(Employee(
          id: event.docs[i].reference.id,
          name: doc['name'],
          lastName: doc['lastName'],
          curp: doc['curp'],
          phone: doc['phone'],
        ));
      }
      widget.current_employees.addAll(x);

        setState(() {});

    });

    collectionStream.listen((event) {
      widget.current_services.clear();
      List<Servicio> x = [];
      for (var i = 0; i < event.docs.length; i++) {
        var doc = event.docs[i].data();
        List<Employee> employees = [];
        List<String> employees_id = List<String>.from(doc['staff']);
        for(var j = 0; j < employees_id.length; j++){
          var e = widget.current_employees.firstWhereOrNull((element) => element.id == employees_id[j]);
          if(e != null){
            employees.add(e);
          }
        }
        x.add(Servicio(
            id: event.docs[i].reference.id,
            name: doc['name'],
            description: doc['description'],
            duration: doc['duration'],
            price: double.parse(doc['price']),
            category: doc['category'],
            staff: employees));

      }
      widget.current_services.addAll(x);

        setState(() {});

    });



    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Servicios'),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF3A6186),
                  Color(0xFF89253E),
                ],
              ),
            ),
          ),
        ),
          body: ListView.builder(
              itemCount: widget.current_services.length,
              itemBuilder: (context, index){
                return Container(
                  margin: const EdgeInsets.all(16.0),
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                      color: Colors.grey[100],
                      borderRadius: BorderRadius.circular(8.0)
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.current_services[index].name.toString(),
                        style: const TextStyle(
                            fontSize: 20.0,
                        ),
                      ),
                      Text(widget.current_services[index].description.toString(),
                        style: const TextStyle(
                            fontSize: 15.0,
                        ),
                      ),
                      Row(
                        children: [
                          Material(
                            borderRadius: BorderRadius.circular(30),
                            elevation: 5,
                            color: Color(0xFF97C0B5),
                            child: Container(
                              width: 65,
                              height: 15,
                              child: Center(
                                child: Text(
                                  '\$${widget.current_services[index].price.toStringAsFixed(2)}',
                                  style: TextStyle(fontSize: 11, color: Color(0xFF258965), fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ),
                          Padding(padding: EdgeInsets.all(16)),
                          Material(
                            borderRadius: BorderRadius.circular(30),
                            elevation: 5,
                            color: Color(0xFFA0AFC0),
                            child: Container(
                              width: 65,
                              height: 15,
                              child: Center(
                                child: Text(
                                  widget.current_services[index].duration.toString()+" mins",
                                  style: TextStyle(fontSize: 11, color: Color(0xFF3A6186), fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(padding: EdgeInsets.all(16)),
                      Text("Elegir un staff",
                        style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w100
                        ),
                      ),
                      Column(
                        children: [
                          Center(
                            child: Column(
                              children: [
                                DropdownButtonExample(
                                  staff_list: widget.current_services[index].staff,
                                  callback: (e){
                                    selected_employee = e;
                                  },
                                ),
                                Padding(padding: EdgeInsets.all(16)),
                                ConfirmarCitaButton(
                                  text: 'Confirmar cita',
                                  gradientColors: [Color(0xFF3A6186), Color(0xFF89253E)],
                                  onPressed: () {
                                    if(selected_employee != null){
                                      Navigator.push(
                                          context, MaterialPageRoute(builder: (context) => AgendarCitaPage(selected_service: widget.current_services[index], selected_employee: selected_employee!))
                                      );
                                    }
                                  },
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                );
              }
          )
      ),
    );
  }
}

// --------------------------------- //

class ConfirmarCitaButton extends StatefulWidget {
  const ConfirmarCitaButton({
    super.key,
    required this.text,
    required this.gradientColors,
    required this.onPressed
});

  final String text;
  final List<Color> gradientColors;
  final void Function() onPressed;

  @override
  State<ConfirmarCitaButton> createState() => _ConfirmarCitaButtonState();
}

class _ConfirmarCitaButtonState extends State<ConfirmarCitaButton> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: widget.gradientColors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(4.0),
      ),
      child: ElevatedButton(
        onPressed: widget.onPressed,
        style: ElevatedButton.styleFrom(
          primary: Colors.transparent,
          elevation: 0.0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.0)),
        ),
        child: Text(widget.text),
      ),
    );
  }

}


// --------------------------------- //
class GradientButton extends StatelessWidget {
  final String text;
  final List<Color> gradientColors;
  final VoidCallback onPressed;

  GradientButton({required this.text, required this.gradientColors, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: gradientColors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(4.0),
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          primary: Colors.transparent,
          elevation: 0.0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.0)),
        ),
        child: Text(text),
      ),
    );
  }
}
